#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <string.h>

#include "SetScreen.h"

void Print_Menu();
void Select_Menu();
