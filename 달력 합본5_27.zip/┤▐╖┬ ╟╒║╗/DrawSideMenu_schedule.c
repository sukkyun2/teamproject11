#include "DrawSideMenu_schedule.h"

void Print_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintSideMenu_background();
	Print_scheduleinfo();
}

