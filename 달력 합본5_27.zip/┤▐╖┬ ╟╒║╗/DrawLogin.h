#pragma once
#include"DrawCenterBox.h"

COORD loginpos;

void Print_login();
void getloginSize();
void Printlogin_background();
void Print_ChangeID();
