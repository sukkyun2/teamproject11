#include "login.h"

#include"DefinePage.h"

#include"menu.h"

#include"staff.h"

int main()
{
	Login();
	PrintHomepage();
}