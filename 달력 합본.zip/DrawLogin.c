#include "DrawLogin.h"

int login_width, login_height;

void Print_login()
{
	DrawCenterBox(50, 20);
	getcenter();

	loginpos.X = 6.0*onecols - 17;
	loginpos.Y = 3.75*onerows - 8;

	gotoxy(loginpos.X, loginpos.Y);
	printf("* ���� ���� ���� ���α׷� *");
	gotoxy(loginpos.X, loginpos.Y+9);
	printf("ID : ");
	gotoxy(loginpos.X, loginpos.Y+11);
	printf("PW : ");
	gotoxy(loginpos.X-13, loginpos.Y+21);	
	printf("* ID�� 0000�� �Է��Ͻø� ID,PW�� ������ �� �ֽ��ϴ�.");
}

void Print_ChangeID()
{
	DrawCenterBox(50, 20);
	getcenter();

	loginpos.X = 6.0*onecols - 17;
	loginpos.Y = 3.75*onerows - 8;

	gotoxy(loginpos.X, loginpos.Y + 5);
	printf("ID : ");
	gotoxy(loginpos.X, loginpos.Y + 7);
	printf("PW : ");
	gotoxy(loginpos.X, loginpos.Y + 11);
	printf("new ID : ");
	gotoxy(loginpos.X, loginpos.Y + 13);
	printf("new PW : ");

}
