#pragma once
#include "SetScreen.h"

int statusbar_width, statusbar_height;

void PrintStatusbar();
void PrintHomeButton();