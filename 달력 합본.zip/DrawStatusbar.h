#pragma once
#include "SetScreen.h"

void PrintStatusbar();
void PrintHomeButton();