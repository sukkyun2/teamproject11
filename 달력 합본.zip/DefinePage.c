#include"DefinePage.h"

void PrintHomepage()
{
	setFullscreen();
	system("cls");
	PrintStatusbar();
	PrinttodayCalendar();
	Print_MainMenu();
	Print_Navigator();
	Select_Menu();
}

void PrintStaffpage()
{
	PrintStatusbar();

}