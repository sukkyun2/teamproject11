#include"DefinePage.h"

int PrintHomepage()
{
	setfFullscreen();
	PrintStatusbar();
	setfFullscreen();
	PrinttodayCalendar();
	Print_MainMenu();
	return HomePage;
}

int PrintStaffpage()
{
	PrintStatusbar();
	
	return StaffMainPage;
}