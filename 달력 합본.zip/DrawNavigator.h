#pragma once

#ifndef DRAWNAVIGATOR_H
#define DRAWNAVIGATOR_H

#include "DrawUI.h"

void Print_navigatorinfo();

void Print_Navigator();


#endif