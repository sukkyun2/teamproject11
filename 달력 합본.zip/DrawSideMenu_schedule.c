#include "DrawSideMenu_schedule.h"

void Print_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintSideMenu_background();
	Print_scheduleinfo();
}

void Print_Insert_scheduleMenu()
{
	getform();
	PrinttodayCalendar();

	PrintSideMenu_background();
	Print_Insert_scheduleinfo();
}