#include "DrawSideMenu_schedule.h"

void Print_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintSideMenu_background();
	Print_scheduleinfo();
}


void Print_Insert_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintSideMenu_background();
	Print_Insert_scheduleinfo();
}


void Print_Delete_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintSideMenu_background();
	Print_Delete_scheduleinfo();
}






