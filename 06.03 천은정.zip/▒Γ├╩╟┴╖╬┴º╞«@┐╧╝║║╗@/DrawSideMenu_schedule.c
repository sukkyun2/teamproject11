#include "DrawSideMenu_schedule.h"

void Print_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintMenu();
	Print_scheduleinfo();
}


void Print_Insert_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintMenu();
	Print_Insert_scheduleinfo();
}


void Print_Delete_scheduleSMenu()
{
	getform();
	PrinttodayCalendar();

	PrintMenu();
	Print_Delete_scheduleinfo();
}






