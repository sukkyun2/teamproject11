#pragma once
#include"SetScreen.h"

void getcenter();

void getCenterBoxSize(int width, int height);

void DrawCenterBox(int width, int height);
