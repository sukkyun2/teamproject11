#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <string.h>

#include"DrawCenterBox.h"

#define _CRT_SECURE_NO_WARNINGS

void Login();