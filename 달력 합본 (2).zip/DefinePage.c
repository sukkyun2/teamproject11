#include"DefinePage.h"

void PrintHomepage()
{
	PAGE = HomePage;

	setfFullscreen();
	system("cls");
	PrintStatusbar();
	PrinttodayCalendar();
	Print_MainMenu();
	while (!be_input())
	{
		Select_Menu();
	}
	if (get_input(&key, &pos) != 0)
	{
		MOUSE_EVENT;
		HomepageControl(pos);
	}
}

void PrintStaffpage()
{
	PrintStatusbar();

}