#pragma once

#include <Windows.h>

void setfFullscreen();
COORD getfFullscreen();
void gotoxy(int x, int y);
