#pragma once

#include <Windows.h>

COORD pos_start, pos_end;
int onerows, onecols;

void setfFullscreen();
COORD getfFullscreen();
void getform();
void gotoxy(int x, int y);
