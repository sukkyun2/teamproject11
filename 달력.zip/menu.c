#pragma once

#include "menu.h"

int Ask_Menunum()
{
	int menu;
	COORD tmp;

	getSideMenusize();
	tmp.X = pos_start.X + 3;	tmp.Y = pos_start.Y + 2; + 2;
	gotoxy(tmp.X, tmp.Y);
	scanf_s("%d", &menu);

	return menu;
}

int Check()
{
	if (MessageBox(NULL, TEXT("�����Ͻðڽ��ϱ� ?"), TEXT("Check Box"), MB_YESNO | MB_ICONQUESTION) == IDYES)
		return 1;
	else
		return 0;
}