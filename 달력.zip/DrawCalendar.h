#pragma once

#include "GetDate.h"
#include "SetScreen.h"

int calendar_width, calendar_height;

void PrintSelectdateButton();
void getCalendarSize();
void PrintCalendar_background();
void PrintCalendarweek();
void PrintCalendarMonth(ldate date);
void PrintCalendardate(ldate date);
void PrintCalendardata(ldate date);