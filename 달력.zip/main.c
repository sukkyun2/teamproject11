#include"DrawCalendar.h"
#include"GetDate.h"
#include"SetScreen.h"

#include"DrawMainMenu.h"

int main()
{
	setfFullscreen();
	GetToday();
	PrintCalendarform();
	PrintCalendardata(today);
	setfFullscreen();
	Print_Menu();
}