#include "login.h"

#include"DefinePage.h"

#include"menu.h"


int main()
{
	Login();
	PrintHomepage();
}