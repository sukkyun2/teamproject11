#include"DrawCalendar.h"
#include"GetDate.h"
#include"SetScreen.h"

int main()
{
	//���� ��¥ ���
	setfFullscreen();
	GetToday(today);
	PrintCalendarform();
	GetDay(today);
	PrintCalendardata(today);
}