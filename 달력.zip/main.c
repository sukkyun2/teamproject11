#include"DrawCalendar.h"
#include"GetDate.h"
#include"SetScreen.h"
#include"staff.h"
#include"DrawMainMenu.h"

int main()
{
	setfFullscreen();
	Print_Menu();
}