#pragma once

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <time.h>

typedef struct localdate
{
	int tm_mday;  /* Day of month (1--31) */
	int tm_mon; /* Month (0--11) */
	int tm_year;  /* Year (calendar year minus 1900) */
}ldate;

ldate today, selcted_day;
int weekday, monthday;

void GetToday();
void GetSelectedday();
void GetMonthDay(ldate date);
void GetWeekDay(ldate date, int day);
void GetDay(ldate date);
