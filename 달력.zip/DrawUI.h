#pragma once
#ifndef DRAWUI_H
#define DRAWUI_H

#include"setting.h"

COORD pos_start, pos_end;
int width, height;
int calendar_width, calendar_height;

void DrawBOX(COORD tmp, int width, int height);

void PrintLoginInputbox();

void PrintStatusbarSize();

void PrintStatusbar();

void PrintHomeButton();

void PrintSelectdateButton();

void PrinttSelectdateInputbox();

void PrinttodaydateButton();

void getCalendarSize();

void PrintCalendar_background();

void PrintCalendarweek();

void PrintCalendarform();

void Printmenu();

void getSideMenusize();

void PrintSideMenu();

void print_askMenunum();

void Printmanagement();

#endif