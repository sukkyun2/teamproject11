#pragma once
#ifndef LOGIN_H
#define LOGIN_H

#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <string.h>

#include"DrawUI.h"
#include"data.h" 

#define _CRT_SECURE_NO_WARNINGS

#define loginButton 0
#define changePageButton 1
#define getInput 2

void Print_login();

void Print_ChangeID();

void PrintLoginButtons(int menu);

void PrintchangeIDButtons(int menu);

void Login();

void ChangeLogin();

void get_input_login(int* menu, int* check, login* tmpID);

void get_input_changeID(int* menu, int* check, login* tmpID, login* newID);

void input_pw(char* buf, int size);

void input_id(char* buf, int size);

void print_start();

#endif