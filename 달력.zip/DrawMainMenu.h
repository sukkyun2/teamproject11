#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <string.h>
#include "staff.h"
#include "SetScreen.h"

#define MenuNum 5

int menu_width, menu_height;

void Select_Menu();
void getmenuSize();
void PrintMenu_background();
void Print_Menuinfo();
void Print_Menu();
