#pragma once

#ifndef STAFF_H
#define STAFF_H

#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <string.h>

#include "DrawUI.h"
#include"data.h"

#define max_people 100
#define staffMenuNum 5

// ����

staff head;
staff retData;
char newname[10];

void Print_staffinfo();

void Staff();
void Insert_Staff();
void Delete_Staff();
void Change_Staff();
void Retrieve_Staff();
void Retrieve();
int Check();
#endif