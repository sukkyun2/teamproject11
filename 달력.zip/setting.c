#include "setting.h"

void setFullscreen()
{
	HWND console_window = GetConsoleWindow();
	HANDLE console_out = GetStdHandle(STD_OUTPUT_HANDLE);

	remove_scrollbar();
	system("TITLE �������� ���α׷�");	// ���α׷���
	system("COLOR 07");					// ȭ�� �������(����ȭ��/�Ͼ�۾�)

	COORD largest_size = GetLargestConsoleWindowSize(console_out);

	--largest_size.X;
	--largest_size.Y;

	SetConsoleScreenBufferSize(console_out, largest_size);

	ShowWindow(console_window, SW_MAXIMIZE);
}
//https://docs.microsoft.com/en-us/windows/console/setconsoledisplaymode

void setLoginscreen()
{
	HANDLE wHnd;
	int width = 55; int height = 20;

	remove_scrollbar();
	system("TITLE �α���");	// ���α׷���
	system("COLOR cf");

	SMALL_RECT windowSize = { 0, 0, width - 1, height - 1 };
	COORD bufferSize = { width , height };
	wHnd = GetStdHandle(STD_OUTPUT_HANDLE);

	SetConsoleWindowInfo(wHnd, 1, &windowSize);
	SetConsoleScreenBufferSize(wHnd, bufferSize);
}

COORD getFullscreen()
{
	COORD fullscreen;
	fullscreen = GetLargestConsoleWindowSize(GetStdHandle(STD_OUTPUT_HANDLE));
	return fullscreen;
}

void getform()
{
	pos_full.X = getFullscreen().X;
	pos_full.Y = getFullscreen().Y;

	onecols = (int)((double)pos_full.X / 12.0);
	onerows = (int)((double)(pos_full.Y - 6.0) / 8.5);
}

void remove_scrollbar()
{
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO info;
	GetConsoleScreenBufferInfo(handle, &info);
	COORD new_size =
	{
		info.srWindow.Right - info.srWindow.Left + 1,
		info.srWindow.Bottom - info.srWindow.Top + 1
	};
	SetConsoleScreenBufferSize(handle, new_size);
}
//��ó: https://wowan.tistory.com/6?category=682208 [DevWarehouse]

void gotoxy(int x, int y)
{                                       // ��ǥ�� ���
	COORD Cur;
	Cur.X = x;
	Cur.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Cur);
}

void textcolor(int foreground, int background)
{
	int color = foreground + background * 16;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}