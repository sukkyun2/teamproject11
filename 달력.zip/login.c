#include "login.h"

void Print_login()
{
	COORD tmp;
	tmp.X = 5 / 2;	tmp.Y = 0;
	DrawBOX(tmp, 50, 20);

	pos_start.X = 55 / 2;	pos_start.Y = 22 / 2;

	gotoxy(pos_start.X - strlen("  * ���� ���� ���� ���α׷� *  ") / 2, 0);
	printf("  * ���� ���� ���� ���α׷� *  ");
	gotoxy(20, 6);
	printf("ID : "); PrintLoginInputbox();

	gotoxy(20, 8);
	printf("PW : "); PrintLoginInputbox();

	gotoxy(4, 18);
	printf("��,��Ű : ��ư ��ȯ, ���ͷ� ����");
}

void Print_ChangeID()
{
	COORD tmp;
	int i;
	tmp.X = 5 / 2;	tmp.Y = 0;
	DrawBOX(tmp, 50, 20);

	pos_start.X = 55 / 2;	pos_start.Y = 22 / 2;

	gotoxy(pos_start.X - strlen("  *���� ���� ���� ���α׷� *  ") / 2, 0);
	printf("  * ���� ���� ���� ���α׷� *  ");
	gotoxy(16, 4);
	printf("old ID : "); PrintLoginInputbox();
	gotoxy(16, 6);
	printf("old PW : "); PrintLoginInputbox();

	gotoxy(16,10);
	printf("new ID : "); PrintLoginInputbox();
	gotoxy(16,12);
	printf("new PW : "); PrintLoginInputbox();

}

void PrintLoginButtons(int menu)
{
	COORD tmp;
	if (menu == loginButton)	// �α��� ��ư
	{
		tmp.X = 13 - strlen("  Change ID  ") / 2; tmp.Y = 14;
		DrawboldBOX(tmp, strlen("  Change ID  "), 3);
		gotoxy(13 - strlen("LOGIN") / 2, 15);
		printf("LOGIN");

		tmp.X = 41 - strlen("  Change ID  ") / 2; tmp.Y = 14;
		DrawBOX(tmp, strlen("  Change ID  "), 3);
		gotoxy(41 - strlen("Change ID") / 2, 15);
		printf("Change ID");
	}
	else if (menu == changePageButton)	// ��й�ȣ �����ư
	{
		tmp.X = 13 - strlen("  Change ID  ") / 2; tmp.Y = 14;
		DrawBOX(tmp, strlen("  Change ID  "), 3);
		gotoxy(13 - strlen("LOGIN") / 2, 15);
		printf("LOGIN");

		tmp.X = 41 - strlen("  Change ID  ") / 2; tmp.Y = 14;
		DrawboldBOX(tmp, strlen("  Change ID  "), 3);
		gotoxy(41 - strlen("Change ID") / 2, 15);
		printf("Change ID");
	}
}

void PrintchangeIDButtons(int menu)
{
	COORD tmp;
	if (menu == loginButton)	// �α��� ��ư
	{
		tmp.X = 13 - strlen("  Update ID  ") / 2; tmp.Y = 14;
		DrawboldBOX(tmp, strlen("  Update ID  "), 3);
		gotoxy(13 - strlen("Update ID") / 2, 15);
		printf("Update ID");

		tmp.X = 41 - strlen("  Update ID  ") / 2; tmp.Y = 14;
		DrawBOX(tmp, strlen("  Update ID  "), 3);
		gotoxy(41 - strlen("UNDO") / 2, 15);
		printf("UNDO");
	}
	else if (menu == changePageButton)	// ��й�ȣ �����ư
	{
		tmp.X = 13 - strlen("  Update ID  ") / 2; tmp.Y = 14;
		DrawBOX(tmp, strlen("  Update ID  "), 3);
		gotoxy(13 - strlen("Update ID") / 2, 15);
		printf("Update ID");

		tmp.X = 41 - strlen("  Update ID  ") / 2; tmp.Y = 14;
		DrawboldBOX(tmp, strlen("  Update ID  "), 3);
		gotoxy(41 - strlen("UNDO") / 2, 15);
		printf("UNDO");
	}
}

void Login()
{
	static int menu = loginButton;
	int s;
	int check = -1;
	login tmpID;

	loadID("account.txt");

	setFullscreen();

	print_start();
	s = getch();

	if (s == ENTER_KEY)
	{
		system("cls");
		setLoginscreen();
		Print_login();
		PrintLoginButtons(menu);

		get_input_login(&menu, &check, &tmpID);
	}
}

void ChangeLogin()
{
	static int menu = loginButton;
	int check = -1;
	login tmpID, newID;

	Print_ChangeID();
	PrintchangeIDButtons(menu);

	get_input_changeID(&menu, &check, &tmpID, &newID);
	Login();
}

void get_input_login(int* menu, int* check, login* tmpID)
{
	int ch;

	gotoxy(27, 6); textcolor(BLACK, WHITE);
	input_id(tmpID->ID, maxlogincharacter);
	textcolor(WHITE, GetStdHandle(STD_OUTPUT_HANDLE));

	gotoxy(27, 8); textcolor(BLACK, WHITE);
	input_pw(tmpID->PW, maxlogincharacter);
	textcolor(WHITE, GetStdHandle(STD_OUTPUT_HANDLE));

	while (check != 1)
	{
		ch = getch();

		if (ch == 0xE0 || ch == 0)
		{
			ch = getch();
			switch (ch)
			{
			case LEFT_KEY:
			case RIGHT_KEY:
				if (*menu == loginButton)	// �α��� ��ư�� ��ġ���ִٸ�
				{
					*menu = changePageButton; PrintLoginButtons(*menu);
				}
				else if (*menu == changePageButton)	// ��ȣ���� ��ư�� ��ġ���ִٸ�
				{
					*menu = loginButton; PrintLoginButtons(*menu);
				}
				break;
			}
		}
		else
		{
			switch (ch)
			{

			case ENTER_KEY:
				if (*menu == loginButton)
				{
					if (strcmp(tmpID->ID, keyID.ID) == 0 && strcmp(tmpID->PW, keyID.PW) == 0)
						check = 1;	// �α��� ����
					else if (strcmp(tmpID->ID, keyID.ID) != 0 || strcmp(tmpID->PW, keyID.PW) != 0)
					{
						MessageBox(NULL, TEXT(" ID,PW�� �߸��Է��ϼ̽��ϴ�."), TEXT("ERR"), MB_OK | MB_ICONSTOP);
					}
				}
				else if (*menu == changePageButton)
				{
					ChangeLogin();
				}
				break;
			}
		}
	}
}

void get_input_changeID(int* menu, int* check, login* tmpID, login* newID)
{
	int ch;

	gotoxy(27, 4); textcolor(BLACK, WHITE);
	input_id(tmpID->ID, maxlogincharacter);
	textcolor(WHITE, GetStdHandle(STD_OUTPUT_HANDLE));


	gotoxy(27, 6); textcolor(BLACK, WHITE);
	input_pw(tmpID->PW, maxlogincharacter);
	textcolor(WHITE, GetStdHandle(STD_OUTPUT_HANDLE));

	gotoxy(27, 10); textcolor(BLACK, WHITE);
	input_id(newID->ID, maxlogincharacter);
	textcolor(WHITE, GetStdHandle(STD_OUTPUT_HANDLE));

	gotoxy(27, 12); textcolor(BLACK, WHITE);
	input_pw(newID->PW, maxlogincharacter);
	textcolor(WHITE, GetStdHandle(STD_OUTPUT_HANDLE));

	while (check != 1)
	{
		ch = getch();

		if (ch == 0xE0 || ch == 0)
		{
			ch = getch();
			switch (ch)
			{
			case LEFT_KEY:
			case RIGHT_KEY:
				if (*menu == loginButton)
				{
					*menu = changePageButton; PrintchangeIDButtons(*menu);
				}
				else if (*menu == changePageButton)
				{
					*menu = loginButton; PrintchangeIDButtons(*menu);
				}
				break;
			}
		}
		else
		{
			switch (ch)
			{
			case ENTER_KEY:
				if (*menu == loginButton)
				{
					if (strcmp(tmpID->ID, keyID.ID) == 0 && strcmp(tmpID->PW, keyID.PW) == 0 && newID->ID != NULL && newID->PW)
					{
						strcpy(keyID.ID, newID->ID); strcpy(keyID.PW, newID->PW);
						saveID("account.txt", keyID);
						check = 1;
					}
					else if (strcmp(tmpID->ID, keyID.ID) != 0 || strcmp(tmpID->PW, keyID.PW) != 0)
					{
						MessageBox(NULL, TEXT(" ID,PW�� �߸��Է��ϼ̽��ϴ�."), TEXT("ERR"), MB_OK | MB_ICONSTOP);
					}
				}
				else if (*menu == changePageButton)
				{
					check = 1;
				}
				break;
			}
		}
	}
}


void input_pw(char* buf, int size)
{
	int cnt = 0, key;  // �Է� ���� ���� ���� Ű 

	while (1)
	{
		key = getch();  // �� ���� �Է¹���

		if (key == ENTER_KEY)  // ���� �Ǵ� �� Ű�� ����
			break;
		if (key == BACKSPACE_KEY)	// �齺���̽� Ű
		{
			printf("\b");
			fputs(" ", stdout);
			printf("\b");

			if (cnt > 0)
				cnt--;
		}
		buf[cnt++] = (char)key;   // ���ۿ� ���� �����ϰ� ī��Ʈ 1 ����  
		putchar('*');  // ȭ�鿡 �� ǥ�� 

		if (cnt == size - 1)  // �ִ� ũ�⸦ �Ѿ�� ���� 
			break;
	}

	buf[cnt] = '\0';    // ���ڿ��� ����� ���� �� ���� ������
}

void input_id(char* buf, int size)
{
	int cnt = 0, key;  // �Է� ���� ���� ���� Ű 

	while (1)
	{
		key = getch();  // �� ���� �Է¹���

		if (key == ENTER_KEY)  // ���� �Ǵ� �� Ű�� ����
			break;
		if (key == BACKSPACE_KEY)	// �齺���̽� Ű
		{
			printf("\b");
			fputs(" ", stdout);
			printf("\b");

			if (cnt > 0)
				cnt--;
		}
		buf[cnt++] = (char)key;   // ���ۿ� ���� �����ϰ� ī��Ʈ 1 ����  
		printf("%c",key);  // ȭ�鿡 �� ǥ�� 

		if (cnt == size - 1)  // �ִ� ũ�⸦ �Ѿ�� ���� 
			break;
	}

	buf[cnt] = '\0';    // ���ڿ��� ����� ���� �� ���� ������
}

void print_start()
{
	HWND myconsole = GetConsoleWindow();
	HDC mydc = GetDC(myconsole);

	HBITMAP hOldBitmap, hImage;
	HDC hMemDC = CreateCompatibleDC(mydc);

	hImage = (HBITMAP)LoadImage(NULL, TEXT("screen.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);

	hOldBitmap = (HBITMAP)SelectObject(hMemDC, hImage);
	BitBlt(mydc, 500, 200, 200 * 10, 200 * 20, hMemDC, 0, 0, SRCCOPY);

	SelectObject(hMemDC, hOldBitmap);
	DeleteObject(hImage);
	DeleteDC(hMemDC);

	ReleaseDC(myconsole, mydc);

}