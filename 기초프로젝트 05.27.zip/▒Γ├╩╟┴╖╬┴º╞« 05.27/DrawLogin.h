#pragma once
#ifndef DRAWLOGIN_H
#define DRAWLOGIN_H

#include"DrawUI.h"

void Print_login();
void Print_ChangeID();

#endif