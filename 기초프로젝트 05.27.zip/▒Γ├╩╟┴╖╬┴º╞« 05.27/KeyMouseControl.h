#pragma once
#ifndef KEYMOUSECONTROL_H
#define KEYMOUSECONTROL_H

#include <windows.h>
#include <stdio.h>

#include "SetScreen.h"

#endif
