#pragma once
#ifndef WORK_H
#define WORK_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "menu.h"
#include "staff.h"

void Print_Work_Menu();

void Work();

void Make_Work();

void search_work(staff , staff , int );

int random_index(int );

#endif