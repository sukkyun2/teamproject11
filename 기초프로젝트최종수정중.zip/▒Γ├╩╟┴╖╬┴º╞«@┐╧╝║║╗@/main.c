#include "login.h"

#include"DefinePage.h"

#include"menu.h"

#include"staff.h"


void main(){

	Login();
	PrintHomepage();
}

